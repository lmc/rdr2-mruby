{
  :preferred_console_coords => [-993, 533, 993, 519],
  :preferred_game_coords    => [-1298, 1, 1296, 759],
}
